export class Product {
  _id: number;
  name: string;
  qty: number;
  price: number;
}
